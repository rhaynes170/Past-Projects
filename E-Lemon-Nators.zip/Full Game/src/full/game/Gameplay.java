package full.game;

import full.game.TitleScreen.Loading; // Imports all necessary files for the game
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;


public class Gameplay extends Pane{
    Gameplay main = this;
    int classNum, health, speed, damage, xp, cLevel, timesSaved, maxHealth;
    double x = 225, y = 225;
    String name;
    Exploration movement;
    boolean allowMove = true, bossDefeated = false, boss2Defeated = false, boss3Defeated = false, isTutorial = false;
    Tutorial pane;
    
    public Gameplay() { // Sets the game info if the user selected to play the Tutorial
        classNum = 1;
        name = "Tutorial";
        maxHealth = 75;
        health = 75;
        speed = 75;
        damage = 75;
        isTutorial = true;
        cLevel = 1;
        
        pane = new Tutorial();
        File file = new File("Game Tile.png"); // Creates the scene of the game
        Image back = new Image(file.toURI().toString());
        ImageView background = new ImageView(back);
        background.setFitWidth(250);
        background.setFitHeight(250);
        
        ImageView background2 = new ImageView(back);
        background2.setFitWidth(250);
        background2.setFitHeight(250);
        background2.setLayoutX(250);
        
        ImageView background3 = new ImageView(back);
        background3.setFitWidth(250);
        background3.setFitHeight(250);
        background3.setLayoutY(250);
        
        ImageView background4 = new ImageView(back);
        background4.setFitWidth(250);
        background4.setFitHeight(250);
        background4.setLayoutX(250);
        background4.setLayoutY(250);
        
        getChildren().addAll(background, background2, background3, background4, pane);
    }
    
    public Gameplay(String name, int classNum, int health, int maxHealth, int speed, int damage, int xp, int cLevel, int timesSaved, boolean bossDefeated, boolean boss2Defeated, boolean boss3Defeated, double x, double y) {
        this.name = name; // Sets the stats of a character if the game was loaded
        this.classNum = classNum;
        this.health = health;
        this.maxHealth = maxHealth;
        this.speed = speed;
        this.damage = damage;
        this.xp = xp;
        this.cLevel = cLevel;
        this.timesSaved = timesSaved;
        this.bossDefeated = bossDefeated;
        this.boss2Defeated = boss2Defeated;
        this.boss3Defeated = boss3Defeated;
        this.x = x;
        this.y = y;
        
        File file = new File("Game Tile.png"); // Creates the scene of the game
        Image back = new Image(file.toURI().toString());
        ImageView background = new ImageView(back);
        background.setFitWidth(250);
        background.setFitHeight(250);
        
        ImageView background2 = new ImageView(back);
        background2.setFitWidth(250);
        background2.setFitHeight(250);
        background2.setLayoutX(250);
        
        ImageView background3 = new ImageView(back);
        background3.setFitWidth(250);
        background3.setFitHeight(250);
        background3.setLayoutY(250);
        
        ImageView background4 = new ImageView(back);
        background4.setFitWidth(250);
        background4.setFitHeight(250);
        background4.setLayoutX(250);
        background4.setLayoutY(250);
        
        movement = new Exploration(false);
        getChildren().addAll(background, background2, background3, background4, movement);
        
        setStats();
    }
    
    public Gameplay(String name, int classNum, int health, int speed, int damage) {
        this.name = name; // Sets the character's stats if the user created a new character
        this.classNum = classNum;
        this.health = health;
        this.maxHealth = health;
        this.speed = speed;
        this.damage = damage;
        xp = 0;
        cLevel = 1;
        this.timesSaved = 0;
        
        File file = new File("Game Tile.png"); // Creates the scene of the game
        Image back = new Image(file.toURI().toString());
        ImageView background = new ImageView(back);
        background.setFitWidth(250);
        background.setFitHeight(250);
        
        ImageView background2 = new ImageView(back);
        background2.setFitWidth(250);
        background2.setFitHeight(250);
        background2.setLayoutX(250);
        
        ImageView background3 = new ImageView(back);
        background3.setFitWidth(250);
        background3.setFitHeight(250);
        background3.setLayoutY(250);
        
        ImageView background4 = new ImageView(back);
        background4.setFitWidth(250);
        background4.setFitHeight(250);
        background4.setLayoutX(250);
        background4.setLayoutY(250);
        
        movement = new Exploration(false);
        getChildren().addAll(background, background2, background3, background4, movement);
    }
    
    public void backToMap() { // Sends the user back to the exploration screen
        getChildren().remove(getChildren().size() - 1);
        allowMove = true;
        createScene();
    }
    
    public void createScene() { // Recreates the map selection screen
        Menu menu = new Menu(); // Creates a menu for saving and quitting a game
        menu.setLayoutX(375);
        menu.setLayoutY(0);
        
        
        this.setOnKeyPressed(e -> {
            if (e.getCode() == e.getCode().X && allowMove && !isTutorial) { // Opens the menu if the user presses X
                getChildren().add(menu);
                final int Y1 = 25, Y2 = 75;

                this.setOnKeyPressed(f  -> { 
                    if (f.getCode() == f.getCode().UP || f.getCode() == f.getCode().DOWN) { // Changes the location of the arrow for selecting an option if the user presses up or down if the menu is open
                        if (menu.arrow.getY() == Y1) {
                            menu.arrow.setY(Y2);
                        } else {
                            menu.arrow.setY(Y1);
                        }
                    }

                    if (f.getCode() == f.getCode().ENTER) { // Selects the option the arrow hovers over if the user presses ENTER
                        if (menu.arrow.getY() == Y1) save();
                        else System.exit(0);
                    } else if (f.getCode() == f.getCode().ESCAPE) backToMap(); // Closes the menu if the user presses ESCAPE
                });

                this.requestFocus();
            }
            
            switch (e.getCode()) { // Moves the character based on the arrow key the user presses as long as the menu is not open
                case UP:
                    if (allowMove && !isTutorial) {
                        movement.moveUp();
                        x = movement.ivModel.getX();
                        y = movement.ivModel.getY();
                    } else if (allowMove && isTutorial)
                        pane.movement.moveUp();
                    break;
                case DOWN:
                    if (allowMove && !isTutorial) {
                        movement.moveDown();
                        x = movement.ivModel.getX();
                        y = movement.ivModel.getY();
                    } else if (allowMove && isTutorial)
                        pane.movement.moveDown();
                    break;
                case LEFT:
                    if (allowMove && !isTutorial) {
                        movement.moveLeft();
                        x = movement.ivModel.getX();
                        y = movement.ivModel.getY();
                    } else if (allowMove && isTutorial)
                        pane.movement.moveLeft();
                    break;
                case RIGHT:
                    if (allowMove && !isTutorial) {
                        movement.moveRight();
                        x = movement.ivModel.getX();
                        y = movement.ivModel.getY();
                    } else if (allowMove && isTutorial)
                        pane.movement.moveRight();
                    break;
            }
            
            
        });
        
        this.requestFocus();
    }
    
    public void setXP(int xp) { // Sets the character's xp
        this.xp = xp;
    }
    
    public void setHealth(int health) { // Sets the character's health
        this.health = health;
    }
    
    public void setLevel(int level) { // Sets the character's level
        cLevel = level;
    }
    
    public void encounter() { // Starts a battle if the user encounters a random enemy
        Battle battle = new Battle(health, maxHealth, speed, damage, xp, cLevel);
        getChildren().add(battle);
    }
    
    public void bossBattle() { // Starts a battle if the user runs into the boss
        Battle battle = new Battle(health, maxHealth, speed, damage, xp, cLevel, "The Lemon King", 150, 50, 25, false);
        getChildren().add(battle);
    }
    
    public void bossBattle2() {
        Battle battle = new Battle(health, maxHealth, speed, damage, xp, cLevel, "The Lemon Tree", 250, 10, 25, false);
        getChildren().add(battle);
    }
    
    public void bossBattle3() {
        Battle battle = new Battle(health, maxHealth, speed, damage, xp, cLevel, "The Ripped Lemon", 100, 100, 50, false);
        getChildren().add(battle);
    }
    
    public void deleteBoss() { // Deletes the boss on the exploration scree n if the user defeats the boss
        movement.getChildren().remove(movement.ivBoss);
        bossDefeated = true;
    }
    
    public void deleteBoss2() {
        movement.getChildren().remove(movement.ivBoss2);
        boss2Defeated = true;
    }
    
    public void deleteBoss3() {
        movement.getChildren().remove(movement.ivBoss3);
        boss3Defeated = true;
    }
    
    public void tutorialBattle() { // Starts a battle with the tutorial enemy
        Battle battle = new Battle(health, maxHealth, speed, damage, xp, cLevel, "Random Dummy", 75, 25, 5, true);
        getChildren().add(battle);
    }
    
    public void save() { // Saves the game
        Loading pane = new Loading(0);
        
        ArrayList<String> names = pane.names;
        
        if (timesSaved == 0) {
            names.add(0, name);
        } else {
            names.add(0, name + "(" + timesSaved + ")");
        }
        
        timesSaved++;
        
        try { // Creates/Edits the list of saves in the user's memory
            FileOutputStream saveFile = new FileOutputStream("saves/saves.sav");
            ObjectOutputStream save = new ObjectOutputStream(saveFile);

            save.writeObject(names);

            save.close();
        } catch(Exception e) {
            getChildren().clear();
            ErrorScreen error = new ErrorScreen("Save process halted due to unknown error.");
            getChildren().add(error);
        }
        
            
        try { // Saves the character's information into a text file
            PrintWriter save = new PrintWriter("saves/" + names.get(0) + ".txt");

            save.println(name);
            save.println(classNum);
            save.println(health);
            save.println(maxHealth);
            save.println(speed);
            save.println(damage);
            save.println(xp);
            save.println(cLevel);
            save.println(timesSaved);
            save.println(bossDefeated);
            save.println(boss2Defeated);
            save.println(boss3Defeated);
            save.println(x);
            save.println(y);
            
            save.close();
        } catch(Exception e){
            getChildren().clear();
            ErrorScreen error = new ErrorScreen("Save process halted due to unknown error.");
            getChildren().add(error);
        }
    }
    
    public void setStats() { // Sets the stats of the character once the character levels up
        switch (classNum) {
            case 1:
                health = 75 + (int)(75 * (cLevel - 1) * .25);
                maxHealth = 75 + (int)(75 * (cLevel - 1) * .25);
                speed = 75 + (int)(75 * (cLevel - 1) * .25);
                damage = 75 + (int)(75 * (cLevel - 1) * .25);
                break;
            case 2:
                health = 125 + (int)(125 * (cLevel - 1) * .25);
                maxHealth = 125 + (int)(125 * (cLevel - 1) * .25);
                speed = 50 + (int)(50 * (cLevel - 1) * .25);
                damage = 75 + (int)(75 * (cLevel - 1) * .25);
                break;
            case 3:
                health = 75 + (int)(75 * (cLevel - 1) * .25);
                maxHealth = 75 + (int)(75 * (cLevel - 1) * .25);
                speed = 125 + (int)(125 * (cLevel - 1) * .25);
                damage = 50 + (int)(50 * (cLevel - 1) * .25);
                break;
            default:
                health = 50 + (int)(50 * (cLevel - 1) * .25);
                maxHealth = 50 + (int)(50 * (cLevel - 1) * .25);
                speed = 75 + (int)(75 * (cLevel - 1) * .25);
                damage = 125 + (int)(125 * (cLevel - 1) * .25);
                break;
        }
    }
    
    class Battle extends Pane {
        String nameOfEnemy = "", combatFeed = "";
        int health, maxHealth, speed, damage, xp, level, enemyHealth, enemySpeed, enemyDamage;
        Button attack = new Button("Attack"), guard = new Button("Guard"), pass = new Button("Pass");
        TextArea battleText = new TextArea();
        boolean isBoss = false, isTutorial;
        
        Timeline animation = new Timeline(new KeyFrame(Duration.millis(1000), e -> { // Creates a transition between displaying a combat feed and the character's options for attacking
            battleText.setVisible(false);
            attack.setVisible(true);
            guard.setVisible(true);
            pass.setVisible(true);
        })), animation2 = new Timeline(new KeyFrame(Duration.millis(500), e -> {
            battleText.setVisible(true);
            attack.setVisible(false);
            guard.setVisible(false);
            pass.setVisible(false);
        }));
        
        Text cCurrentHealth, currentEnemyHealth;
        
        public Battle(int health, int maxHealth, int speed, int damage, int xp, int level) {
            this.health = health; // Creates the battle if the user encountered a random enemy
            this.maxHealth = maxHealth;
            this.speed = speed;
            this.damage = damage;
            this.xp = xp;
            this.level = level;
            
            createBattleScene();
            generateEnemy();
            startBattle();
        }
        
        public Battle(int health, int maxHealth, int speed, int damage, int xp, int level, String bossName, int bossHealth, int bossSpeed, int bossDamage, boolean isTutorial) {
            this.health = health; // Creates the battle if the user encountered a boss
            this.maxHealth = maxHealth;
            this.speed = speed;
            this.damage = damage;
            this.xp = xp;
            this.level = level;
            
            nameOfEnemy = bossName;
            enemyHealth = bossHealth;
            enemySpeed = bossSpeed;
            enemyDamage = bossDamage;
            isBoss = true;
            this.isTutorial = isTutorial;
            
            createBattleScene();
            generateBoss();
            startBattle();
        }
        
        public void generateBoss() { // If the user encountered a boss, the game genereates the boss's sprite
            File enemy;
            if (!isTutorial) {
                if (nameOfEnemy.equals("The Lemon King"))
                    enemy = new File("enemies\\Lemon King.png");
                else if (nameOfEnemy.equals("The Lemon Tree"))
                    enemy = new File("enemies\\Lemon Tree.png");
                else
                    enemy = new File("enemies\\Ripped Lemon.png");
                Image enemyPic = new Image(enemy.toURI().toString());
                ImageView ivEnemy = new ImageView(enemyPic);
                ivEnemy.setFitHeight(112.5);
                ivEnemy.setFitWidth(112.5);
                ivEnemy.setLayoutX(312.5);
                getChildren().add(ivEnemy);
            } else {
                enemy = new File("enemies\\dummy.png");
                Image enemyPic = new Image(enemy.toURI().toString());
                ImageView ivEnemy = new ImageView(enemyPic);
                ivEnemy.setFitHeight(112.5);
                ivEnemy.setFitWidth(112.5);
                ivEnemy.setLayoutX(312.5);
                getChildren().add(ivEnemy);
            }
            
            Text text = new Text(37.5, 150, nameOfEnemy); // Displays the name of the boss
            text.setFont(Font.font("Times", 12));
            getChildren().add(text);
            
            currentEnemyHealth = new Text(140, 150, Integer.toString(enemyHealth)); // Creates a text that sisplays the name of the enemy's current health
            Text enemyTotalHealth = new Text(175, 150, "/" + Integer.toString(enemyHealth));
            
            currentEnemyHealth.setFont(Font.font("Times", 12)); // Creates a text that displays the highest health the enemy can have
            enemyTotalHealth.setFont(Font.font("Times", 12));
            
            getChildren().addAll(enemyTotalHealth, currentEnemyHealth);
        }
        
        public void generateEnemy() {
            int enemyNum = (int)(Math.random() * 4); // Randomly generates an enemy
            
            if (enemyNum != 1) { // Sets the enemy's sprite if the enemy is not the Strong Lemon
                File enemy = new File("enemies\\New Lemon.png");
                Image enemyPic = new Image(enemy.toURI().toString());
                ImageView ivEnemy = new ImageView(enemyPic);
                ivEnemy.setFitHeight(112.5);
                ivEnemy.setFitWidth(112.5);
                ivEnemy.setLayoutX(312.5);
                getChildren().add(ivEnemy);
            } else {
                File enemy = new File("enemies\\New Lemon Armor.png"); // Sets the enemy's sprite if the enemy is the Strong Lemon
                Image enemyPic = new Image(enemy.toURI().toString());
                ImageView ivEnemy = new ImageView(enemyPic);
                ivEnemy.setFitHeight(112.5);
                ivEnemy.setFitWidth(112.5);
                ivEnemy.setLayoutX(312.5);
                getChildren().add(ivEnemy);
            }
            
            switch (enemyNum) {// Sets the enemy's info
                case 0:
                    nameOfEnemy = "Grunt Lemon";
                    enemyHealth = 50 + (int)(50 * (level - 1) * .25);
                    enemySpeed = 50 + (int)(50 * (level - 1) * .25);
                    enemyDamage = 50 + (int)(50 * (level - 1) * .25);
                    break;
                case 1:
                    nameOfEnemy = "Strong Lemon";
                    enemyHealth = 75 + (int)(100 * (level - 1) * .25);
                    enemySpeed = 50 + (int)(50 * (level - 1) * .25);
                    enemyDamage = 50 + (int)(75 * (level - 1) * .25);
                    break;
                case 2:
                    nameOfEnemy = "Fast Lemon";
                    enemyHealth = 50 + (int)(50 * (level - 1) * .25);
                    enemySpeed = 100 + (int)(100 * (level - 1) * .25);
                    enemyDamage = 50 + (int)(75 * (level - 1) * .25);
                    break;
                case 3:
                    nameOfEnemy = "Potent Lemon";
                    enemyHealth = 50 + (int)(50 * (level - 1) * .25);
                    enemySpeed = 50 + (int)(75 * (level - 1) * .25);
                    enemyDamage = 75 + (int)(100 * (level - 1) * .25);
                    break;
            }
            
            Text text = new Text(37.5, 150, nameOfEnemy); // Creates a text that displays the name of the enemy
            text.setFont(Font.font("Times", 12));
            getChildren().add(text);
            
            currentEnemyHealth = new Text(140, 150, Integer.toString(enemyHealth)); // Creates a text that displays the enemy's current health
            Text enemyTotalHealth = new Text(175, 150, "/" + Integer.toString(enemyHealth)); // Creates a text that displays the highest amount of health the enemy can reach
            
            currentEnemyHealth.setFont(Font.font("Times", 12));
            enemyTotalHealth.setFont(Font.font("Times", 12));
            
            getChildren().addAll(enemyTotalHealth, currentEnemyHealth);
        }
        
        public void createBattleScene() {
            
            File battle = new File("BattleGround.png"); // Creates the back of the Battle Screen
            Image battleField = new Image(battle.toURI().toString());
            ImageView background = new ImageView(battleField);
            
            background.setFitHeight(500);
            background.setFitWidth(500);
            
            battleText.setLayoutX(10); // Creates a TextArea that acts as the combat feed
            battleText.setLayoutY(387.5);
            battleText.setPrefSize(480, 100);
            battleText.setFont(Font.font("Times", 12));
            battleText.setEditable(false);
            
            
            attack.setLayoutX(50); // Creates a button that allows the user to attack the enemy
            attack.setLayoutY(412.5);
            attack.setPrefWidth(100);
            attack.setFont(Font.font("Times", 16));
            attack.setVisible(false);
            
            guard.setLayoutX(200); // Creates a button that allows the user to reduce the amount of damage the enemy deals by 10% and pass a turn
            guard.setLayoutY(412.5);
            guard.setPrefWidth(100);
            guard.setFont(Font.font("Times", 16));
            guard.setVisible(false);
            
            pass.setLayoutX(350); // Creates a button that allows the user to pass a turn
            pass.setLayoutY(412.5);
            pass.setPrefWidth(100);
            pass.setFont(Font.font("Times", 16));
            pass.setVisible(false);
            
            File character;
            Image sprite;
            ImageView seeCharacter;
            
            switch (classNum) { // Sets the sprite of the character
                case 1:
                    character = new File("characters//Warrior Back.png");
                    sprite = new Image(character.toURI().toString());
                    seeCharacter = new ImageView(sprite);
                    break;
                case 2:
                    character = new File("characters//Tank Back.png");
                    sprite = new Image(character.toURI().toString());
                    seeCharacter = new ImageView(sprite);
                    break;
                case 3:
                    character = new File("characters//Speedster Back.png");
                    sprite = new Image(character.toURI().toString());
                    seeCharacter = new ImageView(sprite);
                    break;
                default:
                    character = new File("characters//Glass Cannon Back.png");
                    sprite = new Image(character.toURI().toString());
                    seeCharacter = new ImageView(sprite);
                    break;
            }
            
            seeCharacter.setLayoutX(75);
            seeCharacter.setLayoutY(237.5);
            seeCharacter.setFitHeight(112.5);
            seeCharacter.setFitWidth(112.5);
            
            Text cName = new Text(290, 295, name); // Creates a text that displays the character's name
            cName.setFont(Font.font("Times", 12));
            
            cCurrentHealth = new Text(390, 295, Integer.toString(health)); // Creates a text that displays the character's current health
            cCurrentHealth.setFont(Font.font("Times", 12));
            
            Text cMaxHealth = new Text(425, 295, "/" + Integer.toString(maxHealth)); // Creates a text that displays the highest amount of health that the user can have
            cMaxHealth.setFont(Font.font("Times", 12));
            
            getChildren().addAll(background, battleText, attack, guard, pass, seeCharacter, cName, cCurrentHealth, cMaxHealth);
        }
        
        public void startBattle() { // Starts the battle
            battleText.setText(nameOfEnemy + " wishes to fight!"); //Sets the text of the combat feed
            
            animation.play();
            
            
            Timeline tutAni = new Timeline(new KeyFrame(Duration.millis(0), e -> runTutorial()), new KeyFrame(Duration.millis(25000), e -> {
                getChildren().remove(getChildren().size() - 1);
                pass.setDisable(false);
                attack.setDisable(false);
                guard.setDisable(false);
            }));
            
            if (isTutorial) {
                tutAni.play();
                main.setOnKeyPressed(e -> {
                   if (e.getCode() == e.getCode().ENTER) {
                       tutAni.stop();
                       getChildren().remove(getChildren().size() - 1);
                        pass.setDisable(false);
                        attack.setDisable(false);
                        guard.setDisable(false);
                   }
                });
            }
            
            attack.setOnAction(e -> { // Creates the function of the button that attacks the enemy when pressed
                battleText.setText("");
               if (speed > enemySpeed || speed == enemySpeed) { // If the character's speed is greater than or equal to the enemy's speed, the character attacks first. If not, the enemy atack first.
                   animation2.play();
                   playerAttack();
                   
                   if (enemyHealth != 0)
                   enemyAttack(enemyDamage);
               } else {
                   animation2.play();
                   enemyAttack(enemyDamage);
                   
                   if (health != 0)
                   playerAttack();
               }
               combatFeed = "";
            });
            
            guard.setOnAction(e -> { // Creates the function of the button that guards the user from an attack
                battleText.setText("");
                animation2.play();
                combatFeed += "You guarded.\n";
                battleText.setText(combatFeed);
                enemyAttack((int)(enemyDamage * .7));
                combatFeed = "";
            });
            
            pass.setOnAction(e -> { // Creates the function of the button that passes a turn
                battleText.setText("");
                animation2.play();
                combatFeed += "You passed for a turn.\n";
                enemyAttack(enemyDamage);
                combatFeed = "";
            });
        }
        
        public void runTutorial() { // Adds a TextArea that describes how the battle system works
            TextArea info = new TextArea();
            info.setWrapText(true);
            info.setText("See those buttons? They are used to select a fighting option. The Attack button attacks your target, the Guard button passes a turn, but the enemy only does 70% damage to you, and the Pass button passes a turn with you doing nothing at all. The numbers next to your name represent your health and the numbers next to the enemy's name represents the enemy's health. The health numbers read (current health / maximum health). Whoever reaches 0 health loses. If this message has not disappeared yet, press enter.");
            info.setFont(Font.font("Times", 16));
            info.setLayoutX(50);
            info.setLayoutY(200);
            info.setPrefSize(400, 100);
            
            getChildren().add(info);
            
            pass.setDisable(true);
            attack.setDisable(true);
            guard.setDisable(true);
        }
        
        public void playerAttack() { // Deals damage to the enemy based on the character's damage
            enemyHealth -= damage;
            combatFeed += "You deal " + damage + " damage to your opponent.\n";
            battleText.setText(combatFeed);
            
            if (enemyHealth < 0) enemyHealth = 0; // If the enemy's health is less than 0, the enemy's health is set to 0
            
            currentEnemyHealth.setText(Integer.toString(enemyHealth));
            
            checkForWin(); // Checks to see if the enemy died
        }
        
        public void enemyAttack(int enemyDamage) { // The character takes damage from the enemy based on the enemy's damage
            health -= enemyDamage;
            combatFeed += "Your opponent dealt " + enemyDamage + " damage to you.\n";
            battleText.setText(combatFeed);
            
            if(health < 0) health = 0; // If the character's health is less than 0, the character's health is set to 0
            
            cCurrentHealth.setText(Integer.toString(health));
            
            checkForLoss(); // Checks to see if the character died
        }
        
        public void checkForWin() { // Sees if the enemy's health is equal to 0
            if (enemyHealth == 0) { // If the enemy died, the character wins and is prompted to return to the map
                youWin();
            } else {
                animation.setDelay(Duration.millis(1000));
                animation.play();
            }
        }
        
        public void checkForLoss() { // Sees if the chracter's health is equal to 0
            if (health == 0) { // If the character died, the user loses and is prompted to exit the game
                youLose();
            } else {
                animation.setDelay(Duration.millis(1000));
                animation.play();
            }
        }
        
        public void youLose() {
            combatFeed += "You lost the fight.\nGame Over"; // Tells the user that they lost
            battleText.setText(combatFeed);
            
            getChildren().removeAll(attack, guard, pass);
            
            Button exit = new Button("Exit Game"); // Creates a button that exits the game
            exit.setFont(Font.font("Times", 16));
            exit.setPrefWidth(100);
            exit.setLayoutX(200);
            exit.setLayoutY(412.5);
            exit.setVisible(false);
            
            getChildren().add(exit);
            
            Timeline ani = new Timeline(new KeyFrame(Duration.millis(3000), e -> { // Removes the combat feed and adds the Exit Game button
                getChildren().remove(battleText);
                exit.setVisible(true);
            }));
            
            ani.play();
            
            exit.setOnAction(e -> System.exit(0)); // Creates the function of the Exit Game button
        }
        
        public void youWin() {
            combatFeed += "You won the fight!\n"; // Tells the user they won the fight
            battleText.setText(combatFeed);
            
            if (!isBoss) { // Gives a certain amount of xp based on if the enemy was a boss or not
                int xpGain = 25 + (int)(25 * (level - 1) * .25);
                
                combatFeed += "You gained " + xpGain + " xp.\n";
                battleText.setText(combatFeed);
                
                xp += xpGain;
                
                setHealth(health);
                
                checkForLevelUp();
                
                cLevel = level;
                setXP(xp);
            } else {
                int xpGain = 100 + (int)(100 * (level - 1) * .25);
                
                combatFeed += "You gained " + xpGain + " xp.\n";
                battleText.setText(combatFeed);
                
                xp += xpGain;
                
                checkForLevelUp();
                
                cLevel = level;
                setXP(xp);
            }
            
            
            getChildren().removeAll(attack, guard, pass);
            
            Button backToMap; // Creates a button that sends the user back to the map
            if (!isTutorial) backToMap = new Button("Back to the Map");
            else backToMap = new Button("Exit Game");
            backToMap.setFont(Font.font("Times", 16));
            backToMap.setPrefWidth(200);
            backToMap.setLayoutX(150);
            backToMap.setLayoutY(412.5);
            backToMap.setVisible(false);
            
            getChildren().add(backToMap);
            
            Timeline ani = new Timeline(new KeyFrame(Duration.millis(3000), e -> { // Removes the combat feed and adds the button that returns the user to the map screen
                battleText.setVisible(false);
                backToMap.setVisible(true);
            }));
            
            ani.play();
            
            backToMap.setOnAction(e -> { // Creates the function of the button that returns the user to the map screen
                if (!isTutorial) backToMap();
                else System.exit(0);
            });
        }
        
        public void checkForLevelUp() {
            while (xp >= 100 + (int)(100 * (level - 1) * .25)) { // If the user's xp surpasses the required amount, the user levels up and increases their stats
                xp -= 100 + (int)(100 * (level - 1) * .25);
                level++;
                
                setLevel(level);
                setStats();
                
                combatFeed += "You leveled up!\nYou are now level " + level + ".";
                battleText.setText(combatFeed);
            }
        }
    }
    
    class Menu extends Pane {
        Text arrow = new Text(5, 25, ">");
        
        public Menu() {
            createMenu();
        }
        
        public void createMenu() { // Creates the menu that is access on the map
            Rectangle background1 = new Rectangle(0, 0, 125, 100);
            background1.setFill(Color.BLACK);
            
            Rectangle background2 = new Rectangle(5, 5, 115, 90);
            background2.setFill(Color.DARKGREY);
            
            
            arrow.setFont(Font.font("Times", 24));
            arrow.setFill(Color.WHITE);
            
            Text save = new Text(62.5, 25, "Save");
            save.setFont(Font.font("Times", 24));
            save.setFill(Color.WHITE);
            
            Text quit = new Text(62.5, 75, "Quit");
            quit.setFont(Font.font("Times", 24));
            quit.setFill(Color.WHITE);
            
            getChildren().addAll(background1, background2, arrow, save, quit);
            
            
        }
    }
    
    public class Exploration extends Pane {
        ImageView ivModel;
        ImageView ivBoss, ivBoss2, ivBoss3;
        Image[] model = new Image[12];
        boolean isTutorial;
        
        Timeline upMotion = new Timeline(new KeyFrame(Duration.millis(0), e -> ivModel.setImage(model[3])), //Timelines for the walking animations for the character walking in all directions
        new KeyFrame(Duration.millis(250), e -> ivModel.setImage(model[4])),
        new KeyFrame(Duration.millis(500), e -> ivModel.setImage(model[5])));
        
        Timeline downMotion = new Timeline(new KeyFrame(Duration.millis(0), e -> ivModel.setImage(model[0])),
        new KeyFrame(Duration.millis(250), e -> ivModel.setImage(model[1])),
        new KeyFrame(Duration.millis(500), e -> ivModel.setImage(model[2])));
        
        Timeline leftMotion = new Timeline(new KeyFrame(Duration.millis(0), e -> ivModel.setImage(model[6])),
        new KeyFrame(Duration.millis(250), e -> ivModel.setImage(model[7])),
        new KeyFrame(Duration.millis(500), e -> ivModel.setImage(model[8])));
        
        Timeline rightMotion = new Timeline(new KeyFrame(Duration.millis(0), e -> ivModel.setImage(model[9])),
        new KeyFrame(Duration.millis(250), e -> ivModel.setImage(model[10])),
        new KeyFrame(Duration.millis(500), e -> ivModel.setImage(model[11])));
        
        Timeline moveUp = new Timeline(new KeyFrame(Duration.millis(10), e -> {
                ivModel.setY(ivModel.getY() - 1);
                
                upMotion.play();
                
                checkForEncounter();
                    }));
        
        Timeline moveDown = new Timeline(new KeyFrame(Duration.millis(10), e -> {
                ivModel.setY(ivModel.getY() + 1);
                
                downMotion.play();
                
                checkForEncounter();
                    }));
        
        Timeline moveRight = new Timeline(new KeyFrame(Duration.millis(10), e -> { // Timelines that move the character up, down, left, and right
                ivModel.setX(ivModel.getX() + 1);
                
                rightMotion.play();
                
                checkForEncounter();
                    }));
        
        Timeline moveLeft = new Timeline(new KeyFrame(Duration.millis(10), e -> {
                ivModel.setX(ivModel.getX() - 1);
                
                leftMotion.play();
                
                checkForEncounter();
                    }));
        
        
        
        public Exploration(boolean isTutorial) { // Creates the user's sprite that moves and is animated and the sprite of the bosses that, if run into, triggers a boss fight
            this.isTutorial = isTutorial;
            
            File cha;
            
            switch (classNum) {
                case 1:
                    cha = new File("characters\\Warrior Forward.png");
                    model[0] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Forward 2.png");
                    model[1] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Forward 3.png");
                    model[2] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Back.png");
                    model[3] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Back 2.png");
                    model[4] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Back 3.png");
                    model[5] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Left.png");
                    model[6] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Left 2.png");
                    model[7] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Left 3.png");
                    model[8] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Right.png");
                    model[9] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Right 2.png");
                    model[10] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Warrior Right 3.png");
                    model[11] = new Image(cha.toURI().toString());
                    ivModel = new ImageView(model[0]);
                    break;
                case 2:
                    cha = new File("characters\\Tank Forward.png");
                    model[0] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Forward 2.png");
                    model[1] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Forward 3.png");
                    model[2] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Back.png");
                    model[3] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Back 2.png");
                    model[4] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Back 3.png");
                    model[5] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Left.png");
                    model[6] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Left 2.png");
                    model[7] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Left 3.png");
                    model[8] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Right.png");
                    model[9] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Right 2.png");
                    model[10] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Tank Right 3.png");
                    model[11] = new Image(cha.toURI().toString());
                    ivModel = new ImageView(model[0]);
                    break;
                case 3:
                    cha = new File("characters\\Speedster Forward.png");
                    model[0] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Forward 2.png");
                    model[1] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Forward 3.png");
                    model[2] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Back.png");
                    model[3] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Back 2.png");
                    model[4] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Back 3.png");
                    model[5] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Left.png");
                    model[6] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Left 2.png");
                    model[7] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Left 3.png");
                    model[8] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Right.png");
                    model[9] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Right 2.png");
                    model[10] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Speedster Right 3.png");
                    model[11] = new Image(cha.toURI().toString());
                    ivModel = new ImageView(model[0]);
                    break;
                default:
                    cha = new File("characters\\Glass Cannon Forward.png");
                    model[0] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Forward 2.png");
                    model[1] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Forward 3.png");
                    model[2] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Back.png");
                    model[3] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Back 2.png");
                    model[4] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Back 3.png");
                    model[5] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Left.png");
                    model[6] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Left 2.png");
                    model[7] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Left 3.png");
                    model[8] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Right.png");
                    model[9] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Right 2.png");
                    model[10] = new Image(cha.toURI().toString());
                    cha = new File("characters\\Glass Cannon Right 3.png");
                    model[11] = new Image(cha.toURI().toString());
                    ivModel = new ImageView(model[0]);
                    break;
            }
            
            ivModel.setFitHeight(50);
            ivModel.setFitWidth(50 * (16 / 31));
            ivModel.setX(x);
            ivModel.setY(y);
            
            if (!isTutorial) {
                File bossFile = new File("enemies\\Lemon King.png");
                Image boss = new Image(bossFile.toURI().toString());
                ivBoss = new ImageView(boss);
                bossFile = new File("enemies\\Lemon Tree.png");
                boss = new Image(bossFile.toURI().toString());
                ivBoss2 = new ImageView(boss);
                bossFile = new File("enemies\\Ripped Lemon.png");
                boss = new Image(bossFile.toURI().toString());
                ivBoss3 = new ImageView(boss);
                
                ivBoss.setFitHeight(100);
                ivBoss.setFitWidth(100);
                ivBoss.setLayoutX(200);
                ivBoss.setLayoutY(0);
                
                ivBoss2.setFitHeight(100);
                ivBoss2.setFitWidth(100);
                ivBoss2.setLayoutX(10);
                ivBoss2.setLayoutY(200);
                
                ivBoss3.setFitHeight(100);
                ivBoss3.setFitWidth(100);
                ivBoss3.setLayoutX(390);
                ivBoss3.setLayoutY(200);
                
                if(!bossDefeated) getChildren().add(ivBoss);
                if(!boss2Defeated) getChildren().add(ivBoss2);
                if(!boss3Defeated) getChildren().add(ivBoss3);
            } else {
                File bossFile = new File("enemies\\dummy.png");
                Image boss = new Image(bossFile.toURI().toString());
                ivBoss = new ImageView(boss);
                
                ivBoss.setFitHeight(100);
                ivBoss.setFitWidth(100);
                ivBoss.setLayoutX(200);
                ivBoss.setLayoutY(0);
                
                if(!bossDefeated) getChildren().add(ivBoss);
            }
            
            File shopFile = new File("Shop.png");
            Image shop = new Image(shopFile.toURI().toString());
            ImageView ivShop = new ImageView(shop);
            ivShop.setFitHeight(150);
            ivShop.setFitWidth(150);
            ivShop.setLayoutX(175);
            ivShop.setLayoutY(350);
            
            getChildren().addAll(ivModel, ivShop);
            
            if(isTutorial) tutText();
        }
        
        /*
            The next 4 methods move the character in 4 directions based on key input (up, down, left, right)
            After each movement, the game checks to see if the character is in range of the boss and checks to see if the user runs into an enemy
        */
        
        public void moveRight() {
            if (bossDefeated) getChildren().remove(ivBoss);
            if (boss2Defeated) getChildren().remove(ivBoss2);
            if (boss3Defeated) getChildren().remove(ivBoss3);
            
            moveRight.play();
        }
        
        public void moveLeft() {
            if (bossDefeated) getChildren().remove(ivBoss);
            if (boss2Defeated) getChildren().remove(ivBoss2);
            if (boss3Defeated) getChildren().remove(ivBoss3);
            
            moveLeft.play();
        }
        
        public void moveUp() {
            if (bossDefeated) getChildren().remove(ivBoss);
            if (boss2Defeated) getChildren().remove(ivBoss2);
            if (boss3Defeated) getChildren().remove(ivBoss3);
            
            moveUp.play();
        }
        
        public void moveDown() {
            if (bossDefeated) getChildren().remove(ivBoss);
            if (boss2Defeated) getChildren().remove(ivBoss2);
            if (boss3Defeated) getChildren().remove(ivBoss3);
            
            moveDown.play();
        }
        
        public void tutText() { // Adds a TextArea that gives the user directions on how to move
            TextArea instructions = new TextArea();
            instructions.setWrapText(true);
            instructions.setText("Use the arrow keys to move. When you are playing the main game, you can press X to pull up the menu and use the arrow keys to select the various options. While in the menu, you can press escape to close the menu or enter to select an option. When you run into an enemy, you start a battle with it. If you run into a shop, your health is fully restored.");
            instructions.setFont(Font.font("Times", 14));
            instructions.setLayoutX(0);
            instructions.setLayoutY(175);
            instructions.setPrefSize(200, 150);
            instructions.setEditable(false);
            
            getChildren().add(instructions);
        }
        
        public void checkForEncounter() { // Checks to see if the user's sprite has run into contact with a certain enemy or obstacle
            if (!isTutorial && !bossDefeated && (ivModel.getX() >= 150 && ivModel.getX() <= 300) && (ivModel.getY() <= 100)) {
                    ivModel.setImage(model[0]);
                    moveRight.stop();
                    moveLeft.stop();
                    moveUp.stop();
                    moveDown.stop();
                    allowMove = false;
                    deleteBoss();
                    bossBattle();
                } else if (!isTutorial && !boss2Defeated && (ivModel.getX() <= 110) && (ivModel.getY() >= 150 && ivModel.getY() <= 300)) {
                    ivModel.setImage(model[0]);
                    moveRight.stop();
                    moveLeft.stop();
                    moveUp.stop();
                    moveDown.stop();
                    allowMove = false;
                    deleteBoss2();
                    bossBattle2();
                } else if (!isTutorial && !boss3Defeated && (ivModel.getX() >= 340) && (ivModel.getY() >= 150 && ivModel.getY() <= 300)) {
                    ivModel.setImage(model[0]);
                    moveRight.stop();
                    moveLeft.stop();
                    moveUp.stop();
                    moveDown.stop();
                    allowMove = false;
                    deleteBoss3();
                    bossBattle3();
                } else if (!isTutorial && (int)(Math.random() * 450) == 1) {
                    ivModel.setImage(model[0]);
                    moveRight.stop();
                    moveLeft.stop();
                    moveUp.stop();
                    moveDown.stop();
                    allowMove = false;
                    encounter();
                } else if (isTutorial && !bossDefeated && (ivModel.getX() >= 150 && ivModel.getX() <= 300) && (ivModel.getY() <= 100)) {
                    ivModel.setImage(model[0]);
                    moveRight.stop();
                    moveLeft.stop();
                    moveUp.stop();
                    moveDown.stop();
                    allowMove = false;
                    tutorialBattle();
                } else if(ivModel.getY() >= 340) {
                    if (ivModel.getX() > 250 && ivModel.getX() <= 305) {
                        health = maxHealth;
                        System.out.println("Character Healed");
                        ivModel.setX(315);
                    } else if (ivModel.getX() >= 175 && ivModel.getX() < 225) {
                        health = maxHealth;
                        System.out.println("Character Healed");
                        ivModel.setX(165);
                    } else if(ivModel.getX() >= 225 && ivModel.getX() <= 250) {
                        health = maxHealth;
                        System.out.println("Character Healed");
                        ivModel.setY(325);
                    }
                } else if (isTutorial && ivModel.getX() < 200) {
                    if (ivModel.getY() > 125 && ivModel.getY() < 200) {
                        ivModel.setY(115);
                    } else if (ivModel.getY() > 250 && ivModel.getY() < 325) {
                        ivModel.setY(335);
                    } else if (ivModel.getY() >= 200 && ivModel.getY() <= 250) ivModel.setX(210);
                }
        }
    }
    
    public class Tutorial extends Pane { // Creates the tutorial
        Exploration movement = new Exploration(true);
        public Tutorial() {
            getChildren().add(movement);
        }
    }
}