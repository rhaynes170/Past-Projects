package raymondhaes;

/**
 * Raymond Haynes
 * 5/12/17
 * AES encrypter/decrypter
 */

import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
public class RaymondHAES {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Plaintext: ");
        String plain = input.nextLine();
        
        try {
            byte[] key = "thisismysecretke".getBytes("UTF-8"); // Creates the SecretKey for encrypting/decrypting
            SecretKeySpec secKey = new SecretKeySpec(key, "AES");
            
            Cipher aesCipher = Cipher.getInstance("AES/CBC/PKCS5Padding"); // Creates an AES cipher
            
            byte[] byteText = plain.getBytes("UTF-8"); // Converts plaintext to a byte array
            
            byte[] ivStorage = "1234567890abcdef".getBytes("UTF-8"); // Creates an initialization vector
            IvParameterSpec iv = new IvParameterSpec(ivStorage);
            
            aesCipher.init(Cipher.ENCRYPT_MODE, secKey, iv); // Ciphers the plaintext
            byte[] byteCipherText = aesCipher.doFinal(byteText);
            
            System.out.print("Key: " + new String(secKey.getEncoded())); // Prints the key
            
            System.out.println("\nIV: " + new String(iv.getIV())); //Prints the IV
            
            PrintWriter save = new PrintWriter("cipher.txt"); // Saves the encoded ciphertext
            save.print(Base64.getEncoder().encodeToString(byteCipherText));
            
            System.out.println("***File Written***");
            
            save.close();
            
            Scanner load = new Scanner(new File("cipher.txt")); // Loads the encoded ciphertext
            String encryptEncode = load.nextLine();
            
            System.out.println("Encrypted: " + encryptEncode); // Prints the encoded ciphertext
            
            aesCipher.init(Cipher.DECRYPT_MODE, secKey, iv);
            System.out.println("Decrypted: " + new String(aesCipher.doFinal(Base64.getDecoder().decode(encryptEncode)))); // Decrypts the ciphertext and prints the result
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
}
