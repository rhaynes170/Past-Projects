package raymondhbase64;

/**
 * Raymond Haynes
 * 5/10/17
 * Base 64 Encoder and Decoder
 */

import java.io.PrintWriter;
import java.util.Base64;
import java.util.Scanner;
public class RaymondHBase64 {

    
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.println("******************************");
        System.out.println("       Base 64 Encoder");
        System.out.println("******************************");
        
        System.out.print("Enter a message: ");
        String message = input.nextLine();
        
        System.out.println("\nOriginal: " + message);
        
        try {
            String encoded = Base64.getEncoder().encodeToString(message.getBytes("utf-8"));
            
            PrintWriter save = new PrintWriter("message.txt");
            save.print(encoded);

            System.out.println("Base64: " + encoded);

            byte[] asBytes = Base64.getDecoder().decode(encoded);
            System.out.println("Decoded: " + new String(asBytes, "utf-8"));
            
            save.close();
        } catch (Exception e) {
        }
    }
    
}
