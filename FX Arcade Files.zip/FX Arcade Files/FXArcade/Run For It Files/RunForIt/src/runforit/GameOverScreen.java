package runforit;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

public class GameOverScreen extends Pane {
    private long score;
    private String charName;
    
    private ArrayList<Long> highScores = new ArrayList();
    private ArrayList<String> highScorers = new ArrayList();
    
    public GameOverScreen(String charName, long score) { // Creates the main Game Over Screen and sets the name variable and score variable for the class
        this.score = score;
        this.charName = charName;
        
        File gameOverFile = new File("Pictures\\Game Over Screen.png");
        Image gameOver = new Image(gameOverFile.toURI().toString());
        ImageView viewGO = new ImageView(gameOver);
        
        Button viewHigh = new Button("View High Scores");
        viewHigh.setLayoutX(75);
        viewHigh.setLayoutY(220);
        viewHigh.setPrefWidth(150);
        
        getChildren().addAll(viewGO, viewHigh);
        
        viewHigh.setOnAction(e -> {
            getChildren().clear();
            createHighList();
        });
    }
    
    public void createHighList() { // Creates the High Scores screen, which displays you score and the high scores that are saved on a file
        Rectangle back = new Rectangle(0, 0, 300, 250);
        
        TextField yourScore = new TextField("Your Score: " + score);
        yourScore.setEditable(false);
        yourScore.setLayoutX(50);
        yourScore.setLayoutY(5);
        yourScore.setPrefWidth(200);
        
        TextArea displayHigh = new TextArea();
        displayHigh.setEditable(false);
        displayHigh.setLayoutX(10);
        displayHigh.setLayoutY(30);
        displayHigh.setPrefSize(280, 180);
        
        setHighScores();
        
        String high = "";
        for (int i = 0; i < highScores.size(); i++) {
            if (highScorers.get(i).length() <= 4) {
                high += highScorers.get(i) + "\t\t\t\t\t\t\t\t" + highScores.get(i) + "\n";
            } else {
                high += highScorers.get(i) + "\t\t\t\t\t\t\t" + highScores.get(i) + "\n";
            }
        }
        
        displayHigh.setText(high);
        
        Button backToTitle = new Button("Back to Title Screen"); // Sends you back to the title screen
        backToTitle.setLayoutX(50);
        backToTitle.setLayoutY(215);
        backToTitle.setPrefWidth(200);
        
        getChildren().addAll(back, yourScore, displayHigh, backToTitle);
        
        backToTitle.setOnAction(e -> {
           getChildren().clear();
           RFITitleScreen pane = new RFITitleScreen();
           getChildren().add(pane);
        });
        
        this.setOnKeyPressed(e -> { // When Escape is pressed, the game prmopts you to reset the high scores that are saved
            if (e.getCode() == e.getCode().ESCAPE) {
                deleteHighScores();
            }
        });
        this.requestFocus();
    }
    
    public void setHighScores() { // Either creates a new high score list if the program cannot find the correct files or loads a current list
        try {
            FileInputStream getHighFile = new FileInputStream("Saved High Scores\\High Scores.sav");
            ObjectInputStream getHigh = new ObjectInputStream(getHighFile);
            
            highScores = (ArrayList<Long>)getHigh.readObject();
            highScorers = (ArrayList<String>)getHigh.readObject();
            
            getHigh.close();
        } catch (Exception e) {
            try {
                highScores.add((long)10000);
                highScores.add((long)9250);
                highScores.add((long)9000);
                highScores.add((long)8000);
                highScores.add((long)7500);
                highScores.add((long)7000);
                highScores.add((long)6000);
                highScores.add((long)5500);
                highScores.add((long)4000);
                highScores.add((long)3500);
                
                highScorers.add("Steve");
                highScorers.add("Scott");
                highScorers.add("Ray");
                highScorers.add("ItsYaBoy");
                highScorers.add("Austin");
                highScorers.add("Donovan");
                highScorers.add("Nate");
                highScorers.add("Phil");
                highScorers.add("Katie");
                highScorers.add("Matt");
                
                Collections.shuffle(highScorers);
                
                FileOutputStream setHighFile = new FileOutputStream("Saved High Scores\\High Scores.sav");
                ObjectOutputStream setHigh = new ObjectOutputStream(setHighFile);
                
                setHigh.writeObject(highScores);
                setHigh.writeObject(highScorers);
                
                setHigh.close();
            } catch (Exception f) {
            }
        }
        for (int i = 0; i < highScores.size(); i++) {
            if (score > highScores.get(i)) {
                highScores.add(i, score);
                highScores.remove(highScores.size() - 1);
                highScorers.add(i, charName);
                highScorers.remove(highScorers.size() - 1);
                break;
            }
        }
        
        try {
            FileOutputStream setHighFile = new FileOutputStream("Saved High Scores\\High Scores.sav");
            ObjectOutputStream setHigh = new ObjectOutputStream(setHighFile);
                
            setHigh.writeObject(highScores);
            setHigh.writeObject(highScorers);
                
            setHigh.close();
        } catch (Exception e) {
        }
    }
    
    public void deleteHighScores() { // Creates the high score deletion confirmation screen
        getChildren().clear();
        
        Rectangle back = new Rectangle(0, 0, 300, 250);
        
        Text confirm = new Text("Reset the high scores?");
        confirm.setLayoutX(25);
        confirm.setLayoutY(25);
        confirm.setFont(Font.font("Times", 32));
        confirm.setWrappingWidth(250);
        confirm.setTextAlignment(TextAlignment.CENTER);
        confirm.setFill(Color.WHITE);
        
        Button yes = new Button("Yes");
        yes.setLayoutX(25);
        yes.setLayoutY(175);
        yes.setPrefWidth(75);
        
        Button no = new Button("No");
        no.setLayoutX(200);
        no.setLayoutY(175);
        no.setPrefWidth(75);
        
        getChildren().addAll(back, confirm, yes, no);
        
        yes.setOnAction(e -> { // Resets high scores and returns the user to the main menu if the user confirms the reset of the high scores saved
            try {
                highScores.clear();
                highScorers.clear();
                
                highScores.add((long)10000);
                highScores.add((long)9250);
                highScores.add((long)9000);
                highScores.add((long)8000);
                highScores.add((long)7500);
                highScores.add((long)7000);
                highScores.add((long)6000);
                highScores.add((long)5500);
                highScores.add((long)4000);
                highScores.add((long)3500);
                
                highScorers.add("Steve");
                highScorers.add("Scott");
                highScorers.add("Ray");
                highScorers.add("ItsYaBoy");
                highScorers.add("Austin");
                highScorers.add("Donovan");
                highScorers.add("Nate");
                highScorers.add("Phil");
                highScorers.add("Katie");
                highScorers.add("Matt");
                
                Collections.shuffle(highScorers);
                
                FileOutputStream setHighFile = new FileOutputStream("Saved High Scores\\High Scores.sav");
                ObjectOutputStream setHigh = new ObjectOutputStream(setHighFile);
                
                setHigh.writeObject(highScores);
                setHigh.writeObject(highScorers);
                
                setHigh.close();
            } catch (Exception f) {
            }
            
            getChildren().clear();
            RFITitleScreen pane = new RFITitleScreen();
            getChildren().add(pane);
        });
        
        no.setOnAction(e -> { // Simply returns the user to the main menu if the user decides to not reset the high scores
            
            getChildren().clear();
            RFITitleScreen pane = new RFITitleScreen();
            getChildren().add(pane);
        });
    }
}
