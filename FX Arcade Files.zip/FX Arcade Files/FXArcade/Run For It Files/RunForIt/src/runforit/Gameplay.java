package runforit;

import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

/**
 * Creates the game play elements of RunForIt
 */
public class Gameplay extends Pane {
    private long startTime = System.currentTimeMillis(), endTime;
    private ImageView seeChar;
    private String charName;
    private int obstaclesPassed = 0;
    private int dayNightTrans = 0;
    private File[] backgroundFile = {new File("Pictures\\Game Background.png"),
        new File("Pictures\\Game Background 2.png"),
        new File("Pictures\\Game Background 3.png"),
        new File("Pictures\\Game Background 4.png"),
        new File("Pictures\\Game Background 5.png"),
        new File("Pictures\\Game Background 6.png"),
        new File("Pictures\\Game Background 7.png"),
        new File("Pictures\\Game Background 8.png"),
        new File("Pictures\\Game Background 9.png"),
        new File("Pictures\\Game Background 10.png"),
        new File("Pictures\\Game Background 11.png"),
        new File("Pictures\\Game Background 12.png"),
        new File("Pictures\\Game Background 13.png"),
        new File("Pictures\\Game Background 14.png"),
        new File("Pictures\\Game Background 15.png"),
        new File("Pictures\\Game Background 16.png"),
        new File("Pictures\\Game Background Night.png"),
        new File("Pictures\\Game Background Night 2.png"),
        new File("Pictures\\Game Background Night 3.png"),
        new File("Pictures\\Game Background Night 4.png"),
        new File("Pictures\\Game Background Night 5.png"),
        new File("Pictures\\Game Background Night 6.png"),
        new File("Pictures\\Game Background Night 7.png"),
        new File("Pictures\\Game Background Night 8.png"),
        new File("Pictures\\Game Background Night 9.png"),
        new File("Pictures\\Game Background Night 10.png"),
        new File("Pictures\\Game Background Night 11.png"),
        new File("Pictures\\Game Background Night 12.png"),
        new File("Pictures\\Game Background Night 13.png"),
        new File("Pictures\\Game Background Night 14.png"),
        new File("Pictures\\Game Background Night 15.png"),
        new File("Pictures\\Game Background Night 16.png")};
    private ImageView seeBack;
    
    public Gameplay(String charName) { // Creates the background and the character on the screen
        this.charName = charName;
        
        Image background = new Image(backgroundFile[obstaclesPassed % 32].toURI().toString());
        seeBack = new ImageView(background);
        
        File charFile = new File("Pictures\\Running Character.gif");
        Image character = new Image(charFile.toURI().toString());
        seeChar = new ImageView(character);
        seeChar.setX(25);
        seeChar.setY(70);
        seeChar.setFitWidth(75);
        seeChar.setFitHeight(75);
        
        getChildren().addAll(seeBack, seeChar);
        
        addObstacles();
    }
    
    public void addObstacles() { // Adds an obstacle to the screen every few seconds
        seeBack.setImage(new Image(backgroundFile[obstaclesPassed % 32].toURI().toString()));
        NewObstacle pane = new NewObstacle();
        getChildren().add(pane);
    }
    
    public void GameOver() { // Prompts the game to go to the Game Over Screen if the user crashes into an obstacle
        getChildren().clear();
        GameOverScreen pane = new GameOverScreen(charName, Math.round((endTime - startTime) / 10));
        getChildren().add(pane);
    }
    
    public class NewObstacle extends Pane { // Creates a new obstacle during the gameplay
        private boolean gameOver = false;
        private boolean canJump = true;
        private boolean isJumping = false;
        private ImageView seeObst;
        public NewObstacle() { // Adds the obstacle image into the game
            File obstFile;
            
            if ((int)(Math.random() * 2) == 1) {
                obstFile = new File("Pictures\\Box Obstacle.png");
            } else {
                obstFile = new File("Pictures\\Stump Obstacle.png");
            }
            
            Image obstacle = new Image(obstFile.toURI().toString());
            seeObst = new ImageView(obstacle);
            seeObst.setX(290);
            seeObst.setY(95);
            
            getChildren().add(seeObst);
            
            moveObstacle();
        }
        
        public void moveObstacle() { // Creates the hit detection, the jump animation, and the animation of the obstacle getting closer to the character
            Timeline jump = new Timeline(new KeyFrame(Duration.millis(175), g -> { // jump animation
                        if (gameOver)
                            seeChar.setY(48);
                        else
                            seeChar.setY(seeChar.getY() - 25);
                    }),
                    new KeyFrame(Duration.millis(350), g -> {
                        if (gameOver)
                            seeChar.setY(31);
                        else
                            seeChar.setY(seeChar.getY() - 20);
                    }),
                    new KeyFrame(Duration.millis(525), g -> {
                        if (gameOver)
                            seeChar.setY(19);
                        else
                            seeChar.setY(seeChar.getY() - 15);
                    }),
                    new KeyFrame(Duration.millis(700), g -> {
                        if (gameOver)
                            seeChar.setY(12);
                        else
                            seeChar.setY(seeChar.getY() - 10);
                    }),
                    new KeyFrame(Duration.millis(875), g -> {
                        if (gameOver)
                            seeChar.setY(10);
                        else
                            seeChar.setY(seeChar.getY() - 5);
                    }),
                    new KeyFrame(Duration.millis(1050), g -> {
                        if (gameOver)
                            seeChar.setY(18);
                        else
                            seeChar.setY(seeChar.getY() + 5);
                    }),
                    new KeyFrame(Duration.millis(1225), g -> {
                        if (gameOver)
                            seeChar.setY(31);
                        else
                            seeChar.setY(seeChar.getY() + 10);
                    }),
                    new KeyFrame(Duration.millis(1400), g -> {
                        if (gameOver)
                            seeChar.setY(49);
                        else
                            seeChar.setY(seeChar.getY() + 15);
                    }),
                    new KeyFrame(Duration.millis(1575), g -> {
                        if (gameOver)
                            seeChar.setY(72);
                        else
                            seeChar.setY(seeChar.getY() + 20);
                    }),
                    new KeyFrame(Duration.millis(1750), g -> {
                        if (gameOver)
                            seeChar.setY(100);
                        else {
                            seeChar.setY(seeChar.getY() + 25);
                            seeChar.setImage(new Image(new File("Pictures\\Running Character.gif").toURI().toString()));
                        }
                    }),
                    new KeyFrame(Duration.millis(2750), g -> {
                        
                        if (gameOver) {
                            GameOver();
                        }
                    }));
            
            jump.setOnFinished(g -> {
                isJumping(false);
                setJump(true);
            });
            
            Timeline movement = new Timeline(new KeyFrame(Duration.millis(100 / Math.pow(1.5, dayNightTrans)), e -> { // Obstacle motion animation
                seeObst.setX(seeObst.getX() - 10);
                if (seeChar.getX() + 35 >= seeObst.getX() && seeChar.getX() + 30 <= seeObst.getX() + 50 && seeChar.getY() <= 75 && seeChar.getY() >= 25) {
                    endTime = System.currentTimeMillis();
                    removeObstacle(seeObst);
                    setJump(false);
                    seeChar.setRotate(90);
                    Timeline death = new Timeline(new KeyFrame(Duration.millis(0), f -> seeChar.setY(100)),
                    new KeyFrame(Duration.millis(2750), f -> {
                        GameOver();
                    }));
                    if (!isJumping)
                        death.play();
                    seeChar.setImage(new Image(new File("Pictures\\Stationary Character.png").toURI().toString()));
                    setGameOver(true);
                }
                this.setOnKeyPressed(f -> {
                    isJumping(true);
                    if (f.getCode() == f.getCode().SPACE && canJump) {
                        seeChar.setImage(new Image(new File("Pictures\\Stationary Character.png").toURI().toString()));
                        setJump(false);
                        jump.play();
                    }
                });
                this.requestFocus();
                }));
            movement.setCycleCount(34);
            movement.setOnFinished(e -> {
                removeObstacle(seeObst);
                if (!gameOver) {
                    obstaclesPassed++;
                    
                    if (obstaclesPassed % 16 == 0)
                        dayNightTrans++;
                    
                    addObstacles();
                }
            });
            movement.play();
        }
        
        public void removeObstacle(ImageView seeObst) { // Removes the obstacle once it either hits the user or exits the screen
            getChildren().clear();
        }
        
        public void setGameOver(boolean gameOver) { // Tells the program that the game has ended
            this.gameOver = gameOver;
        }
        
        public void setJump(boolean canJump) { // Allows to user to jump to prevent glitches
            this.canJump = canJump;
        }
        
        public void isJumping(boolean isJumping) { // Tells the game that the user is currently jumping
            this.isJumping = isJumping;
        }
    }
}
