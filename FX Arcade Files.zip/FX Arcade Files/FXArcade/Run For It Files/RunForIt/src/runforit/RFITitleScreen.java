package runforit;

import java.io.File;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
public class RFITitleScreen extends Pane{
    public RFITitleScreen() { // Creates the nodes in the Title Screen of the game
        Button start = new Button("Start Game");
        start.setLayoutX(100);
        start.setLayoutY(200);
        start.setPrefWidth(100);
        
        TextField charName = new TextField();
        charName.setLayoutX(25);
        charName.setLayoutY(160);
        charName.setPrefWidth(250);
        
        File backgroundFile = new File("Pictures\\Run For It Title Screen.gif");
        Image background = new Image(backgroundFile.toURI().toString());
        ImageView seeBack = new ImageView(background);
        
        getChildren().addAll(seeBack, start, charName);
        
        start.setOnAction(e -> { // Once the user enters a valid name and presses the button, the game will begin
            if (!charName.getText().equals("") || !charName.getText().equals(" ")) {
                if (charName.getText().length() > 8) {
                    Gameplay pane = new Gameplay(charName.getText().substring(0, 8));
                    getChildren().clear();
                    getChildren().add(pane);
                } else {
                    Gameplay pane = new Gameplay(charName.getText());
                    getChildren().clear();
                    getChildren().add(pane);
                }
            }
        });
    }
}
