package runforit;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * Raymond Haynes
 * 4/13/17
 * RUN FOR IT!!!!!!
 */
public class RunForIt extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();
        
        RFITitleScreen pane = new RFITitleScreen();
        root.setCenter(pane);
        
        Scene scene = new Scene(root, 290, 240);
        primaryStage.setTitle("Run For It");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
