package rockemripoff;

import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.util.Duration;


public class Gameplay extends Pane{
    private int type, bluePunches = 0, redPunches = 0;;
    private ImageView seeRedBot, seeBlueBot, seeRing;
    private boolean blueCanPunch = true, redCanPunch = true, blueHuman, redHuman, redWin = false, blueWin = false;
    
    public Gameplay(int type) {
        this.type = type;
        startMatch();
    }
    
    public void startMatch() {
        File ringFile = new File("Pictures\\Rock 'Em Sock 'Em Ring.png");
        Image ring = new Image(ringFile.toURI().toString());
        seeRing = new ImageView(ring);
        
        File ropeFile = new File("Pictures\\Rock 'Em Sock 'Em Ring Ropes.png");
        Image rope = new Image(ropeFile.toURI().toString());
        ImageView seeRope = new ImageView(rope);
        
        File blueFile = new File("Pictures\\Blue Robot No Punch.png");
        Image blueBot = new Image(blueFile.toURI().toString());
        seeBlueBot = new ImageView(blueBot);
        seeBlueBot.setLayoutX(135);
        seeBlueBot.setLayoutY(100);
        
        File redFile = new File("Pictures\\Red Robot No Punch.png");
        Image redBot = new Image(redFile.toURI().toString());
        seeRedBot = new ImageView(redBot);
        seeRedBot.setLayoutX(195);
        seeRedBot.setLayoutY(100);
        
        File countFile = new File("Pictures\\Countdown.gif");
        Image countdown = new Image(countFile.toURI().toString());
        ImageView seeCount = new ImageView(countdown);
        seeCount.setLayoutX(163);
        seeCount.setLayoutY(25);
        
        getChildren().addAll(seeRing, seeBlueBot, seeRedBot, seeRope, seeCount);
        
        Timeline stopCountdown = new Timeline(new KeyFrame(Duration.millis(4000), e -> getChildren().remove(seeCount)));
        stopCountdown.setOnFinished(e -> play());
        stopCountdown.play();
    }
    
    public void play() {
        int punchCap = (int)(Math.random() * 25) + 10;
        
        Timeline bluePop = new Timeline(new KeyFrame(Duration.millis(0), e -> seeBlueBot.setImage(new Image(new File("Pictures\\Blue Robot Head Pop.gif").toURI().toString()))),
        new KeyFrame(Duration.millis(250), e -> seeBlueBot.setImage(new Image(new File("Pictures\\Blue Robot Head Top.png").toURI().toString()))));
        
        bluePop.setOnFinished(e -> {
            seeRing.setImage(new Image(new File("Pictures\\Red Wins.png").toURI().toString()));
            
            Button back = new Button("Back To Title");
            back.setLayoutX(145);
            back.setLayoutY(265);
            back.setPrefWidth(100);
            
            getChildren().add(back);
            
            back.setOnAction(f -> {
                getChildren().clear();
                RERTitleScreen pane = new RERTitleScreen();
                getChildren().add(pane);
            });
        });
        
        Timeline redPop = new Timeline(new KeyFrame(Duration.millis(0), e -> seeRedBot.setImage(new Image(new File("Pictures\\Red Robot Head Pop.gif").toURI().toString()))),
        new KeyFrame(Duration.millis(250), e -> seeRedBot.setImage(new Image(new File("Pictures\\Red Robot Head Top.png").toURI().toString()))));
        
        redPop.setOnFinished(e -> {
            seeRing.setImage(new Image(new File("Pictures\\Blue Wins.png").toURI().toString()));
            
            Button back = new Button("Back To Title");
            back.setLayoutX(145);
            back.setLayoutY(265);
            back.setPrefWidth(100);
            
            getChildren().add(back);
            
            back.setOnAction(f -> {
                getChildren().clear();
                RERTitleScreen pane = new RERTitleScreen();
                getChildren().add(pane);
            });
        });
        
        Timeline bluePunch = new Timeline(new KeyFrame(Duration.millis(0), f -> {
            bluePunches++;
            if (bluePunches >= punchCap) {
                redCanPunch = false;
                seeRedBot.setLayoutY(80);
                blueWin = true;
                redPop.play();
            }
            seeBlueBot.setImage(new Image(new File("Pictures\\Blue Robot Punching.png").toURI().toString()));
        }),
                new KeyFrame(Duration.millis(250), f -> seeBlueBot.setImage(new Image(new File("Pictures\\Blue Robot No Punch.png").toURI().toString()))));
        
        bluePunch.setOnFinished(e -> {
            if (!blueWin)
                blueCanPunch = true;
        });
        
        Timeline redPunch = new Timeline(new KeyFrame(Duration.millis(0), f -> {
            redPunches++;
            if (redPunches >= punchCap) {
                blueCanPunch = false;
                seeBlueBot.setLayoutY(80);
                redWin = true;
                bluePop.play();
            }
            seeRedBot.setImage(new Image(new File("Pictures\\Red Robot Punching.png").toURI().toString()));
        }),
                new KeyFrame(Duration.millis(250), f -> seeRedBot.setImage(new Image(new File("Pictures\\Red Robot No Punch.png").toURI().toString()))));
        
        redPunch.setOnFinished(e -> {
            if (!redWin)
                redCanPunch = true;
        });
        
        switch (type) {
            case 1:
                blueHuman = true;
                redHuman = true;
                break;
            case 2:
                blueHuman = true;
                redHuman = false;
                break;
            default:
                blueHuman = false;
                redHuman = false;
                break;
        }
        
        this.setOnKeyPressed(e -> {
            if ((e.getCode() == e.getCode().A || e.getCode() == e.getCode().D) && blueCanPunch && blueHuman) {
                blueCanPunch = false;
                
                if (!(bluePunches >= punchCap || redPunches >= punchCap))
                    bluePunch.play();
                else {
                    redCanPunch = false;
                    seeRedBot.setLayoutY(80);
                    blueWin = true;
                    redPop.play();
                }
            }
            if ((e.getCode() == e.getCode().J || e.getCode() == e.getCode().L) && redCanPunch && redHuman ) {
                redCanPunch = false;
                
                if (!(bluePunches >= punchCap || redPunches >= punchCap))
                    redPunch.play();
                else {
                    blueCanPunch = false;
                    seeBlueBot.setLayoutY(80);
                    redWin = true;
                    bluePop.play();
                }
            }
        });
        this.requestFocus();
        
        Timeline comRedTime = new Timeline(new KeyFrame(Duration.millis(800), e -> {
            if (!redHuman && (int)(Math.random() * 8) < 5 && redCanPunch && !blueWin && !redWin)
                redPunch.play();
        }));
        
        comRedTime.setCycleCount(Timeline.INDEFINITE);
        
        Timeline comBlueTime = new Timeline(new KeyFrame(Duration.millis(800), e -> {
            if (!blueHuman && (int)(Math.random() * 8) < 5 && blueCanPunch && !blueWin && !redWin)
                bluePunch.play();
        }));
        
        comBlueTime.setCycleCount(Timeline.INDEFINITE);
        
        comRedTime.play();
        comBlueTime.play();
    }
}