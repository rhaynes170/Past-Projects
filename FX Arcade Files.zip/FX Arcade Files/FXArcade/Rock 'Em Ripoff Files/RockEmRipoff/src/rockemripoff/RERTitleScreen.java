/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rockemripoff;

import java.io.File;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

/**
 *
 * @author programming
 */
public class RERTitleScreen extends Pane{
    public RERTitleScreen() {
        File title = new File("Pictures\\Rock 'Em Sock 'Em Ring Title.png");
        Image screen = new Image(title.toURI().toString());
        ImageView seeScreen = new ImageView(screen);
        
        Button begin = new Button("Begin Playing");
        begin.setLayoutX(150);
        begin.setLayoutY(260);
        begin.setPrefWidth(100);
        
        File ropeFile = new File("Pictures\\Rock 'Em Sock 'Em Ring Ropes.png");
        Image rope = new Image(ropeFile.toURI().toString());
        ImageView seeRope = new ImageView(rope);
        
        File blueFile = new File("Pictures\\Blue Robot No Punch.png");
        Image blueBot = new Image(blueFile.toURI().toString());
        ImageView seeBlueBot = new ImageView(blueBot);
        seeBlueBot.setLayoutX(135);
        seeBlueBot.setLayoutY(100);
        
        File redFile = new File("Pictures\\Red Robot No Punch.png");
        Image redBot = new Image(redFile.toURI().toString());
        ImageView seeRedBot = new ImageView(redBot);
        seeRedBot.setLayoutX(195);
        seeRedBot.setLayoutY(100);
        
        getChildren().addAll(seeScreen, begin, seeBlueBot, seeRedBot, seeRope);
        
        begin.setOnAction(e -> {
            getChildren().clear();
            choosePlayStyle();
        });
    }
    
    public void choosePlayStyle() {
        Rectangle back = new Rectangle(0, 0, 400, 300);
        
        Text prompt = new Text("How do you want to play?");
        prompt.setX(25);
        prompt.setY(50);
        prompt.setWrappingWidth(350);
        prompt.setFont(Font.font("Times", 32));
        prompt.setFill(Color.WHITE);
        prompt.setTextAlignment(TextAlignment.CENTER);
        
        Button pvp = new Button("Player vs. Player");
        pvp.setLayoutX(16.5);
        pvp.setLayoutY(225);
        pvp.setPrefWidth(100);
        
        Button pvc = new Button("Player vs. Com.");
        pvc.setLayoutX(149.5);
        pvc.setLayoutY(225);
        pvc.setPrefWidth(100);
        
        Button cvc = new Button("Com. vs. Com.");
        cvc.setLayoutX(282.5);
        cvc.setLayoutY(225);
        cvc.setPrefWidth(100);
        
        getChildren().addAll(back, prompt, pvp, pvc, cvc);
        
        pvp.setOnAction(e -> {
            getChildren().clear();
            Gameplay pane = new Gameplay(1);
            getChildren().add(pane);
        });
        
        pvc.setOnAction(e -> {
            getChildren().clear();
            Gameplay pane = new Gameplay(2);
            getChildren().add(pane);
        });
        
        cvc.setOnAction(e -> {
            getChildren().clear();
            Gameplay pane = new Gameplay(3);
            getChildren().add(pane);
        });
    }
}
