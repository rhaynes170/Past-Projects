package rockemripoff;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * Raymond Haynes
 * 4/25/17
 * Rock 'Em Sock 'Em Ripoff
 */

public class RockEmRipoff extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        BorderPane root = new BorderPane();
        
        RERTitleScreen pane = new RERTitleScreen();
        root.setCenter(pane);
        
        Scene scene = new Scene(root, 390, 290);
        primaryStage.setTitle("Rock 'Em Ripoff");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
