package fxarcade;

import java.io.File;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import runforit.*;
import rockemripoff.*;

/**
 * Raymond Haynes
 * 4/27/17
 * FX Arcade (Has 2 games, Run For It and Rock 'Em Ripoff)
 */
public class FXArcade extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        Pane root = new Pane();
        
        Rectangle back = new Rectangle(0, 0, 400, 300);
        
        File rerFile = new File("Pictures\\RER Picture.png");
        Image rer = new Image(rerFile.toURI().toString());
        ImageView seeRER = new ImageView(rer);
        seeRER.setLayoutX(25);
        seeRER.setLayoutY(50);
        seeRER.setFitWidth(150);
        seeRER.setFitHeight(150);
        
        File rfiFile = new File("Pictures\\RFI Picture.png");
        Image rfi = new Image(rfiFile.toURI().toString());
        ImageView seeRFI = new ImageView(rfi);
        seeRFI.setLayoutX(225);
        seeRFI.setLayoutY(50);
        seeRFI.setFitWidth(150);
        seeRFI.setFitHeight(150);
        
        Button selRER = new Button("Rock 'Em Ripoff");
        selRER.setLayoutX(25);
        selRER.setLayoutY(seeRER.getLayoutY() + seeRER.getFitHeight() + 10);
        selRER.setPrefWidth(seeRER.getFitWidth());
        
        Button selRFI = new Button("Run For It");
        selRFI.setLayoutX(225);
        selRFI.setLayoutY(seeRFI.getLayoutY() + seeRFI.getFitHeight() + 10);
        selRFI.setPrefWidth(seeRFI.getFitWidth());
        
        root.getChildren().addAll(back, seeRER, selRER, seeRFI, selRFI);
        
        selRER.setOnAction(e -> {
            primaryStage.setWidth(410);
            primaryStage.setHeight(325);
            root.getChildren().clear();
            RERTitleScreen pane = new RERTitleScreen();
            root.getChildren().add(pane);
        });
        
        selRFI.setOnAction(e -> {
            primaryStage.setWidth(310);
            primaryStage.setHeight(275);
            root.getChildren().clear();
            RFITitleScreen pane = new RFITitleScreen();
            root.getChildren().add(pane);
        });
        
        Scene scene = new Scene(root, 390, 290);
        primaryStage.setTitle("FX Arcade");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.setResizable(false);
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
